<?php

$host = "localhost";
$user = "root";
$password = "";
$db = "db_rpl";

// Melakukan koneksi ke database
$conn = mysqli_connect($host, $user, $password, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal " . mysqli_connect_error());
}

echo "Koneksi berhasil";

?>